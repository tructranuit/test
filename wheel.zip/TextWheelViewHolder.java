package com.example.viewbinding.sample.modules.wheel;

import android.widget.TextView;

public class TextWheelViewHolder extends BaseWheelPickerView.ViewHolder<TextWheelPickerView.Item> {
    private final TextView textView;

    public TextWheelViewHolder(TextView textView) {
        super(textView);
        this.textView = textView;
    }

    @Override
    public void onBindData(TextWheelPickerView.Item data) {
        textView.setText(data.getText());
    }
}
