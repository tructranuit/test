package com.example.viewbinding.sample.modules.wheel;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.core.content.ContextCompat;

import com.example.viewbinding.sample.R;

public class TextWheelPickerView extends BaseWheelPickerView {
    public static class Item {
        private final String id;
        private final CharSequence text;

        public Item(String id, CharSequence text, boolean isEnabled) {
            this.id = id;
            this.text = text;
        }

        public String getId() {
            return id;
        }

        public CharSequence getText() {
            return text;
        }
    }

    public TextWheelPickerView(Context context) {
        this(context, null);
    }

    public TextWheelPickerView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TextWheelPickerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        View highlightView = new View(context);
        Drawable highlightBackground = ContextCompat.getDrawable(context, R.drawable.text_wheel_highlight_bg);
        highlightView.setBackground(highlightBackground);
        addView(highlightView);

        FrameLayout.LayoutParams highlightLayoutParams = (FrameLayout.LayoutParams) highlightView.getLayoutParams();
        if (highlightLayoutParams == null) {
            highlightLayoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            highlightView.setLayoutParams(highlightLayoutParams);
        }
        highlightLayoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
        highlightLayoutParams.height = context.getResources().getDimensionPixelSize(R.dimen.text_wheel_picker_item_height);
        highlightLayoutParams.gravity = Gravity.CENTER_VERTICAL;
    }

}
