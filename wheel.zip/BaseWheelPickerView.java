package com.example.viewbinding.sample.modules.wheel;

import static androidx.recyclerview.widget.RecyclerView.NO_POSITION;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;
import java.util.List;

public abstract class BaseWheelPickerView extends FrameLayout implements WheelPickerRecyclerView.WheelPickerRecyclerViewListener {

    public interface AdapterImp {
        boolean isCircular();

        void setCircular(boolean isCircular);

        int getValueCount();
    }

    public interface WheelPickerViewListener {
        void didSelectItem(BaseWheelPickerView picker, int index);

        void onScrollStateChanged(int state);
    }

    public abstract static class ViewHolder<Element> extends RecyclerView.ViewHolder {
        public ViewHolder(View itemView) {
            super(itemView);
        }

        public abstract void onBindData(Element data);
    }

    @SuppressLint("NotifyDataSetChanged")
    public abstract static class Adapter<Element, ViewHolder extends BaseWheelPickerView.ViewHolder<Element>> extends RecyclerView.Adapter<ViewHolder> implements AdapterImp {
        private List<Element> values = Collections.emptyList();
        private boolean isCircular = false;

        public void setValues(List<Element> values) {
            this.values = values;
            notifyDataSetChanged();
        }

        public List<Element> getValues() {
            return values;
        }

        @Override
        public void setCircular(boolean isCircular) {
            if (this.isCircular == isCircular) {
                return;
            }
            this.isCircular = isCircular;
            notifyDataSetChanged();
        }

        @Override
        public boolean isCircular() {
            return isCircular;
        }

        @Override
        public int getValueCount() {
            return values.size();
        }

        @Override
        public int getItemCount() {
            return values.size();
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Element value = values.get(position);
            holder.onBindData(value);
        }
    }

    private WheelPickerRecyclerView recyclerView;

    private WheelPickerViewListener listener;

    public BaseWheelPickerView(Context context) {
        this(context, null);
    }

    public BaseWheelPickerView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BaseWheelPickerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initRecyclerView();
    }

    private void initRecyclerView() {
        recyclerView = new WheelPickerRecyclerView(getContext());
        addView(recyclerView, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        recyclerView.setWheelListener(this);
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                if (listener != null) {
                    listener.onScrollStateChanged(newState);
                }
            }
        });
    }

    public <Element, VH extends BaseWheelPickerView.ViewHolder<Element>> void setAdapter(Adapter<Element, VH> adapter) {
        recyclerView.setAdapter(adapter);
    }

    public void setWheelListener(WheelPickerViewListener listener) {
        this.listener = listener;
    }

    public void setSelectedIndex(int index) {
        setSelectedIndex(index, false, null);
    }

    public void setSelectedIndex(int index, boolean animated) {
        setSelectedIndex(index, animated, null);
    }

    public void setSelectedIndex(int index, boolean animated, Runnable completion) {
        int dstPosition = isCircular() ? index - getSelectedIndex() + recyclerView.getCurrentPosition() : index;
        if (animated) {
            recyclerView.smoothScrollToCenterPosition(dstPosition, true, completion);
        } else {
            recyclerView.scrollToCenterPosition(dstPosition, true, completion);
        }
    }

    public int getSelectedIndex() {
        int position = recyclerView.getCurrentPosition();
        if (isCircular()) {
            int valueCount = 0;
            if (recyclerView.getAdapter() instanceof AdapterImp) {
                valueCount = ((AdapterImp) recyclerView.getAdapter()).getValueCount();
            }
            return valueCount > 0 ? position % valueCount : NO_POSITION;
        } else {
            return position;
        }
    }

    public void setHapticFeedbackEnabled(boolean hapticFeedbackEnabled) {
        super.setHapticFeedbackEnabled(hapticFeedbackEnabled);
        recyclerView.setHapticFeedbackEnabled(hapticFeedbackEnabled);
    }

    public void refreshCurrentPosition() {
        recyclerView.refreshCurrentPosition();
    }

    public boolean isCircular() {
        if (recyclerView.getAdapter() instanceof AdapterImp) {
            return ((AdapterImp) recyclerView.getAdapter()).isCircular();
        }
        return false;
    }

    public void setCircular(boolean circular) {
        AdapterImp adapter = null;
        if (recyclerView.getAdapter() instanceof AdapterImp) {
            adapter = (AdapterImp) recyclerView.getAdapter();

        }
        if (adapter == null) {
            return;
        }
        if (adapter.isCircular() == circular) {
            return;
        }
        adapter.setCircular(circular);
        recyclerView.refreshCurrentPosition();
        int selectedIndex = getSelectedIndex();
        if (circular) {
            int valueCount = adapter.getValueCount();
            if (valueCount > 0) {
                recyclerView.scrollToCenterPosition(((Integer.MAX_VALUE / 2) / valueCount) * valueCount + selectedIndex, true, null);
            } else {
                recyclerView.scrollToCenterPosition(selectedIndex, true, null);
            }
        } else {
            recyclerView.scrollToCenterPosition(selectedIndex, true, null);
        }
    }

    @Override
    public void didSelectItem(int position) {
        if (listener != null) {
            listener.didSelectItem(this, getSelectedIndex());
        }
    }
}
