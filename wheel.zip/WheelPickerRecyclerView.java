package com.example.viewbinding.sample.modules.wheel;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewTreeObserver;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;


public class WheelPickerRecyclerView extends RecyclerView {
    public interface WheelPickerRecyclerViewListener {
        void didSelectItem(int position);
    }

    private WheelPickerRecyclerViewListener listener;
    private WheelSnapHelper snapHelper;
    private int hapticFeedbackLastTriggerPosition;
    private boolean ignoreHapticFeedback;
    private int currentPosition = NO_POSITION;
    private ViewTreeObserver.OnGlobalLayoutListener scrollToCenterPositionListener;

    public WheelPickerRecyclerView(Context context) {
        this(context, null);
    }

    public WheelPickerRecyclerView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public WheelPickerRecyclerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        snapHelper = new WheelSnapHelper();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        linearLayoutManager.setStackFromEnd(true);
        setLayoutManager(linearLayoutManager);

        snapHelper.attachToRecyclerView(this);
        setOverScrollMode(OVER_SCROLL_NEVER);
        setHasFixedSize(true);
        addItemDecoration(new OffsetItemDecoration());

        SimpleItemAnimator itemAnimator = (SimpleItemAnimator) getItemAnimator();
        if (itemAnimator != null) {
            itemAnimator.setSupportsChangeAnimations(false);
        }
    }

    public void setWheelListener(WheelPickerRecyclerViewListener listener) {
        this.listener = listener;
    }

    @Override
    public void setAdapter(Adapter adapter) {
        super.setAdapter(adapter);
        if (adapter != null) {
            adapter.registerAdapterDataObserver(new AdapterDataObserver() {
                @Override
                public void onChanged() {
                    refreshCurrentPosition();
                }
            });
        }
    }

    @Override
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        invalidateItemDecorations();
    }

    @Override
    public void scrollToPosition(int position) {
        scrollToCenterPosition(position, null);
    }

    @Override
    public void smoothScrollToPosition(int position) {
        smoothScrollToCenterPosition(position, null);
    }

    private void smoothScrollToCenterPosition(int position, final Runnable completion) {
        super.smoothScrollToPosition(position);
        post(() -> {
            LinearLayoutManager layoutManager = (LinearLayoutManager) getLayoutManager();
            if (layoutManager == null) {
                return;
            }

            View view = layoutManager.findViewByPosition(position);
            if (view == null) {
                return;
            }

            int[] snapDistance = snapHelper.calculateDistanceToFinalSnap(layoutManager, view);
            if (snapDistance != null && (snapDistance[0] != 0 || snapDistance[1] != 0)) {
                addOnScrollListener(onScrollListener(completion));
                smoothScrollBy(snapDistance[0], snapDistance[1]);
            } else {
                if (completion != null) {
                    completion.run();
                }
            }
        });
    }

    private OnScrollListener onScrollListener(Runnable completion) {
        return new OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                if (newState != SCROLL_STATE_IDLE) {
                    return;
                }
                recyclerView.removeOnScrollListener(this);
                refreshCurrentPosition();
                if (completion != null) {
                    completion.run();
                }
            }
        };
    }

    public void smoothScrollToCenterPosition(int position, boolean ignoreHapticFeedback, Runnable completion) {
        if (ignoreHapticFeedback && isHapticFeedbackEnabled()) {
            this.ignoreHapticFeedback = true;
            smoothScrollToCenterPosition(position, () -> {
                this.ignoreHapticFeedback = false;
                if (completion != null) {
                    completion.run();
                }
            });
        } else {
            smoothScrollToCenterPosition(position, completion);
        }
    }

    private void scrollToCenterPosition(int position, final Runnable completion) {
        if (scrollToCenterPositionListener != null) {
            getViewTreeObserver().removeOnGlobalLayoutListener(scrollToCenterPositionListener);
        }

        scrollToCenterPositionListener = new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                getViewTreeObserver().removeOnGlobalLayoutListener(this);
                LinearLayoutManager layoutManager = (LinearLayoutManager) getLayoutManager();
                if (layoutManager == null) {
                    return;
                }

                View view = layoutManager.findViewByPosition(position);
                if (view == null) {
                    return;
                }

                int[] snapDistance = snapHelper.calculateDistanceToFinalSnap(layoutManager, view);
                if (snapDistance != null && (snapDistance[0] != 0 || snapDistance[1] != 0)) {
                    scrollBy(snapDistance[0], snapDistance[1]);
                }

                refreshCurrentPosition();
                if (completion != null) {
                    completion.run();
                }
            }
        };

        getViewTreeObserver().addOnGlobalLayoutListener(scrollToCenterPositionListener);
        super.scrollToPosition(position);
    }

    public void scrollToCenterPosition(int position, boolean ignoreHapticFeedback, Runnable completion) {
        if (ignoreHapticFeedback && isHapticFeedbackEnabled()) {
            this.ignoreHapticFeedback = true;
            scrollToCenterPosition(position, () -> {
                this.ignoreHapticFeedback = false;
                if (completion != null) {
                    completion.run();
                }
            });
        } else {
            scrollToCenterPosition(position, completion);
        }
    }

    public int getCurrentPosition() {
        return currentPosition;
    }

    private void setCurrentPosition(int value) {
        if (currentPosition == value) {
            return;
        }
        currentPosition = value;
        if (getScrollState() == SCROLL_STATE_IDLE) {
            if (listener != null) {
                listener.didSelectItem(value);
            }
        }
    }

    @Override
    public void onScrolled(int dx, int dy) {
        super.onScrolled(dx, dy);

        int visibleCenterItemPosition = visibleCenterItemPosition();
        if (visibleCenterItemPosition == NO_POSITION) {
            return;
        }

        if (currentPosition == NO_POSITION) {
            setCurrentPosition(visibleCenterItemPosition);
        }

        if (hapticFeedbackLastTriggerPosition != visibleCenterItemPosition) {
            hapticFeedbackLastTriggerPosition = visibleCenterItemPosition;
            if (isHapticFeedbackEnabled() && !ignoreHapticFeedback) {
                performHapticFeedback(
                        HapticFeedbackConstants.KEYBOARD_TAP,
                        HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                );
            }
        }
    }

    @Override
    public void onScrollStateChanged(int state) {
        super.onScrollStateChanged(state);
        if (state == SCROLL_STATE_IDLE) {
            setCurrentPosition(visibleCenterItemPosition());
        }
    }

    public void refreshCurrentPosition() {
        setCurrentPosition(visibleCenterItemPosition());
    }

    private int visibleCenterItemPosition() {
        LinearLayoutManager layoutManager = (LinearLayoutManager) getLayoutManager();
        if (layoutManager == null) {
            return NO_POSITION;
        }

        int firstIndex = layoutManager.findFirstVisibleItemPosition();
        int lastIndex = layoutManager.findLastVisibleItemPosition();
        for (int i = firstIndex; i <= lastIndex; i++) {
            ViewHolder holder = findViewHolderForAdapterPosition(i);
            if (holder == null) {
                continue;
            }

            View child = holder.itemView;
            int centerY = getHeight() / 2;
            if (child.getTop() <= centerY && child.getBottom() >= centerY) {
                return i;
            }
        }
        return NO_POSITION;
    }

    // reference: https://github.com/devilist/RecyclerWheelPicker/blob/master/recyclerwheelpicker/src/main/java/com/devilist/recyclerwheelpicker/widget/RecyclerWheelPicker.java
    @Override
    public boolean drawChild(Canvas canvas, View child, long drawingTime) {
        if (canvas == null || child == null) {
            return super.drawChild(canvas, child, drawingTime);
        }

        int centerY = (getHeight() - getPaddingBottom() - getPaddingTop()) / 2;
        float childCenterY = child.getTop() + child.getHeight() / 2F;
        float factor = (centerY - childCenterY) / centerY;
        float alphaFactor = 1 - 0.7f * Math.abs(factor);
        child.setAlpha(alphaFactor * alphaFactor * alphaFactor);


        canvas.save();
        boolean result = super.drawChild(canvas, child, drawingTime);
        canvas.restore();
        return result;
    }
}
