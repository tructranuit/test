package com.example.viewbinding.sample.modules.wheel;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.viewbinding.sample.R;

public class TextWheelAdapter extends BaseWheelPickerView.Adapter<TextWheelPickerView.Item, TextWheelViewHolder> {
    @NonNull
    @Override
    public TextWheelViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        TextView view = (TextView) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.wheel_picker_item, parent, false);
        return new TextWheelViewHolder(view);
    }
}
