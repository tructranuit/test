package com.example.viewbinding.sample.modules.wheel;

import android.view.View;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

public class WheelSnapHelper extends LinearSnapHelper {
    @Override
    public View findSnapView(RecyclerView.LayoutManager layoutManager) {
        LinearLayoutManager linearLayoutManager = (LinearLayoutManager) layoutManager;
        if (isValidSnap(linearLayoutManager)) {
            return super.findSnapView(layoutManager);
        }
        return null;
    }

    private boolean isValidSnap(LinearLayoutManager linearLayoutManager) {
        int firstCompletelyVisibleItemPosition = linearLayoutManager.findFirstCompletelyVisibleItemPosition();
        int lastCompletelyVisibleItemPosition = linearLayoutManager.findLastCompletelyVisibleItemPosition();
        return firstCompletelyVisibleItemPosition != 0 && lastCompletelyVisibleItemPosition != linearLayoutManager.getItemCount() - 1;
    }
}