package com.example.viewbinding.sample.modules.main.view

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.children
import androidx.work.*
import com.example.viewbinding.sample.R
import com.example.viewbinding.sample.databinding.ActivityMainBinding
import com.example.viewbinding.sample.databinding.Example3CalendarDayBinding
import com.example.viewbinding.sample.databinding.Example3CalendarHeaderBinding
import com.example.viewbinding.sample.modules.fragment.SampleAdapter
import com.example.viewbinding.sample.modules.main.MyWorker
import com.example.viewbinding.sample.modules.test.BottomSheetDialog
import com.example.viewbinding.sample.modules.wheel.BaseWheelPickerView
import com.example.viewbinding.sample.modules.wheel.TextWheelAdapter
import com.example.viewbinding.sample.modules.wheel.TextWheelPickerView
import com.kizitonwose.calendarview.model.CalendarDay
import com.kizitonwose.calendarview.model.CalendarMonth
import com.kizitonwose.calendarview.model.DayOwner
import com.kizitonwose.calendarview.ui.DayBinder
import com.kizitonwose.calendarview.ui.MonthHeaderFooterBinder
import com.kizitonwose.calendarview.ui.ViewContainer
import com.kizitonwose.calendarview.utils.next
import com.kizitonwose.calendarview.utils.previous
import java.security.SecureRandom
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit


class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityMainBinding

    private lateinit var pickerView: TextWheelPickerView

    private var startDate: LocalDate? = null
    private var endDate: LocalDate? = null

    private var selectedDate: LocalDate? = null
    private val today = LocalDate.now()
    private val titleFormatter = DateTimeFormatter.ofPattern("MMMM yyyy")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =
            com.example.viewbinding.sample.databinding.ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        pickerView = binding.custom
        val textAdapter = TextWheelAdapter()
        textAdapter.values = (15 until 170).map {
            TextWheelPickerView.Item(
                "$it",
                "this is item - item $it",
                true
            )
        }
        pickerView.setAdapter(textAdapter)

        handleCalendar(savedInstanceState)


        val permissions = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION,
            )
        } else {
            arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT

            )
        }
        ActivityCompat.requestPermissions(this, permissions, 0)

        pickerView.setWheelListener(object : BaseWheelPickerView.WheelPickerViewListener {
            override fun didSelectItem(picker: BaseWheelPickerView, index: Int) {
                Log.e("AAAAAAAAAAAAA", "itemSelected = $index")
            }

            override fun onScrollStateChanged(state: Int) {
                //
            }
        })

//        showBottomSheetDialog()
        pickerView.selectedIndex = 10

        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CHANGE_WIFI_STATE), 1)

//        binding.txtSample.text = "View Binding Sample"
        binding.btnRemove.setOnClickListener(this)
        binding.btnTxt.setOnClickListener(this)

        binding.viewPager.adapter = SampleAdapter(this, supportFragmentManager)
//        binding.viewPager.offscreenPageLimit = 2
//        binding.viewPager.measure(
//            ViewGroup.LayoutParams.MATCH_PARENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//        testDecrypt()

//        scheduleRecurringFetchWeatherSyncUsingWorker()
    }

    private fun showBottomSheetDialog() {
        val bottomSheetDialogFragment = BottomSheetDialog()
//        bottomSheetDialogFragment.exitTransition = Slide(Gravity.BOTTOM);
        bottomSheetDialogFragment.show(supportFragmentManager, bottomSheetDialogFragment.tag)
    }

    fun scheduleRecurringFetchWeatherSyncUsingWorker() {
        val constraints: Constraints = Constraints.Builder().apply {
            setRequiredNetworkType(NetworkType.CONNECTED)
            setRequiresBatteryNotLow(true)
        }.build()

        val request: PeriodicWorkRequest = PeriodicWorkRequest.Builder(
            MyWorker::class.java, 15, TimeUnit.MINUTES
        )
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(this).cancelAllWork()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "ScanBLE",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    @SuppressLint("MissingPermission")
    override fun onClick(p0: View?) {
        when (p0?.id) {
            R.id.btn_remove -> {
                val wifiManager: WifiManager =
                    applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val networkConfigurations = wifiManager.configuredNetworks
                networkConfigurations?.forEach {
                    Log.e("AAAAAAAAAAAA", "${it.SSID}, ${it.networkId}")
                    val ssid = binding.etSsid.text.toString()
                    if (it.SSID.contains(ssid, true)) {
                        val isRemoved = wifiManager.removeNetwork(it.networkId)
                        Log.e("AAAAAAAAAA", "Removed = ${isRemoved}")

                        val isSaved = wifiManager.saveConfiguration()
                        Log.e("AAAAAAAAAA", "isSaved = ${isSaved}")
                    }
                }
            }
            R.id.btn_txt -> {
//                showBottomSheetDialog()
                val v = SecureRandom()
                val max = 50
                val min = 1

                val x = (v.nextInt(max - min + 1) + min)
                pickerView.setSelectedIndex(x)
            }
        }
    }

//    fun testDecrypt() {
//
//        try {
//            val private = "LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQpNSUlFb3dJQkFBS0NBUUVBNHlYMUpFVDBOcmxsM29yN0NCL1FVRzlXRmZkTkVOcjVINWNzZkc0WXp3YXVLRWpvCmhtVnlXL0VGem03c3JuTHcvVTM3dFBZV0R5dmw4R254VlE0TmIvdko5RUxic01Ia0tvdGVkNnN6akpmL3F1VWwKcmx3ZHFYdEc5YTI4bDZqSjFmcDFzazk3QlBKdTVqVHhXbFB3Z3Q1OWx6bXlPTlVjdFBVWnluNE1SenlLOERJRQprc214cVMxZVhrWXFxWXVuUk9DTGkwbnlLTC82Qk1ONlVMMytiTnBQUTlIYnRsVVdpUTMrNDBGa0QyZ0pid1Z4CkdKdVFtbjE4NUVBNFVHRFNIQ3lqR1lDbkJ4MW5idzZmWXVOc2Q3RndiZ2lFclZiRUlXS0o4WTEwS1NNVlkrVUIKYVFLa2xYc3FxZExiYkJLbHZYNlc3OE0yN2o4eEo0VkNCUVEvWHdJREFRQUJBb0lCQUd1WTIxcG0zMWZjMG9ocwpSU1ZBREtsTlUvWHJ3ekdzeUQxU210d0dPdkkyTStFWlNDd0JlZjViV1dqRDJwRjRHUGVrTFFzM1ZwT3hNNmFDClNMTUZpUS8yc1Y5bkhESEtabzVRbmxzSldjM0xZbXhOUjJBa2VsaUI4TWNIbVVJdHpnM3lLalpndCtGTUJZUSsKcCtVbHhkUDRHSDI5OHRKQkFPd20vaVNST0xlMDdaWGdRQXlVd2tzYWhVVHlwbndOb3Q0Ri9mTnhQMzRMc3dGVQplVjV0aFpTVmpiaThHYW9KZ2pOUDNNeEpjSEFTcS83N2Rvc0UxTjI4Z2RrQzBZOHlWWFRwRVcyOGJ0UisrQnE2Ck5QdEtIWTc0bTI1YitCR1hZQnQ1dzZWVDlvQnFkWlJ4R2ZYRnpOb3dMSk5hR0tIYi9hVlgwN2prU0RVcmZlY2wKVXYxUDJhRUNnWUVBOG41cXJxbWhaRVFzdUZhSm92WUhNVDZrTTRLUU9mcjZNa0tmOGd6OGExZlE3UzZnbnlqSApseTlMMElnK2dTZEMzajQxQ1JZV0xXaU93RzhoMzBJQVdCR3NVazVOc25FYlYzcUttZVJsUzZhalJlVU1NblYzClNaL1psOGlpMlBVUUs4ZlEvZjl1eFUxa1p3d2t2c0huRzBiVWZ0Rzk2dnVvelA2UDRSQ1NQL1VDZ1lFQTc4eTgKdzYzeElJQ2pPeEFWR2NWK1Zhc2ZjdWZIbFFXclFGZzZFbk1oNUZkSFQ0OGYzYzBXNmJCY2ZHNUtFQjRNL1dTcgo4ZDVYVnp1dlYzR005YmhxN1g4TkM1RXgvb0hGN01kVzdzbXNpQjQ1TVQxYTN0S0RadlNCdXJnQ3IrSFZUL0NJCklxQThpY0FkVGpFUjdSRXRzR0xERnFDQzFJZEJYTWhSU3FLTlVZTUNnWUFTZ3ZvTDZXRXJzVlNrb2Q2UjlTd3AKWXpuUHdOalh4RVFUVUNpN3BxZ2lYYXJTWUd2Y21wVmFBajlNWlFvNGU5SEwrMzI2K3Rlb2tjSE1DTy9TQmt6VwpiRXIyWVlubTVHR005UXJkb3FUaytJeWdTbEw3Q3lLWEdUL1lLWFhkRUNBeTUyY1o3TVQ5Qk9KMFIyWUt0ZXk1CmxWZWxjc2VIeDd4a0ljN0VCS3JWZlFLQmdCUk0xTDRMLzVtc3lpUzUyODl1dEo4eitWbVUzWVIwRW1kRUVNWjMKRUt0djZBMklKRDUybWpYMlJCNFVpQmlOTXJSUXpXMlFVUHlGaFBaMkdtVEMwK3AvRXUranZ3TzRvTFRHdTBsRApzV05raTVycmdzSFNPR1dDMVdpbEl6VVlmU0pqVG1NQUJaL3pyNGRyQ0FWMXF0Ui94OXdtZ216VGRta1FYREZoClNXMVpBb0dCQUlPeGxCYVhrTkUvSThNRExhMWxWNTBaTGNONkR0R2o3T0tlOGR5SUZwTFBCNkpkME5na3oxUGQKRDBlNkNJQTlnMVdyemRndks0ZDEyeWJSWm12cUFWR291RXBQMDhYd3J0czhMbnd0VnhJYjRLeDJFZlR1dU1mRwo0WUxuSU9nRTNyaWRGNlY3QWlOZzFJdUpScWdsT3h5b2p3TlNmZktHVjVQQjVEVG9tdHNaCi0tLS0tRU5EIFJTQSBQUklWQVRFIEtFWS0tLS0tCg=="
//            val privateKeyDec = Base64.decode(private, Base64.DEFAULT)
//            val key = String(privateKeyDec)
//            // remove header and footer of key
//            val privateKeyStr = key
//                .substring(28, key.length - 26)
//                .replace(Regex(System.lineSeparator()), "")
//            Log.i("SAAAAAAAAAAA", privateKeyStr)
//            val encoded: ByteArray = Base64.decode(privateKeyStr, Base64.NO_WRAP)
//            val keyFactory: KeyFactory = KeyFactory.getInstance("RSA")
//            val keySpec = PKCS8EncodedKeySpec(encoded)
//            val rsaPrivateKey = keyFactory.generatePrivate(keySpec)
//
//            val file = File("/sdcard/Test/ota_patch.zip")
//            Log.i("AAAA", file.exists() .toString())
//            val zipFile = ZipFile(file)
//            val headers = zipFile.fileHeaders
//            val downloadFirmwarePath = "/sdcard/firmware/"
//            if (!File(downloadFirmwarePath).exists() && File(downloadFirmwarePath).mkdirs()) {
//            }
//            zipFile.extractFile(headers[0].fileName, downloadFirmwarePath, "firmware.bin")
//            val downloadedFirmwareFile = FirmwareFile(this)
//            downloadedFirmwareFile.parse(File("$downloadFirmwarePath/firmware.bin"), rsaPrivateKey)
//
//        } catch (e: java.lang.Exception) {
//            e.printStackTrace()
//        }
//
//
//    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == 0) {
            var isAllPermissionGranted = true;
            grantResults.forEach {
                if (it != PackageManager.PERMISSION_GRANTED) {
                    isAllPermissionGranted = false
                    return@forEach
                }
            }
            if (isAllPermissionGranted) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION),
                    1
                )
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    private fun selectDate(date: LocalDate) {
        if (selectedDate != date) {
            val oldDate = selectedDate
            selectedDate = date
            oldDate?.let { binding.calendarView.notifyDateChanged(it) }
            binding.calendarView.notifyDateChanged(date)
        }
    }

    private fun handleCalendar(savedInstanceState: Bundle?) {
        val daysOfWeek = daysOfWeekFromLocale()
        val currentMonth = YearMonth.now()
        binding.calendarView.apply {
            setup(currentMonth.minusMonths(2), currentMonth.plusMonths(0), daysOfWeek.first())
            scrollToMonth(currentMonth)
        }

        if (savedInstanceState == null) {
            binding.calendarView.post {
                selectDate(today)
            }
        }

        endDate = LocalDate.now()
        startDate = endDate!!.minusDays(60)

        binding.btnNextMonth.setOnClickListener {
            binding.calendarView.findFirstVisibleMonth()?.let {
                binding.calendarView.smoothScrollToMonth(it.yearMonth.next)
            }
        }

        binding.btnPreviousMonth.setOnClickListener {
            binding.calendarView.findFirstVisibleMonth()?.let {
                binding.calendarView.smoothScrollToMonth(it.yearMonth.previous)
            }
        }

        class DayViewContainer(view: View) : ViewContainer(view) {
            lateinit var day: CalendarDay // Will be set when this container is bound.
            val binding = Example3CalendarDayBinding.bind(view)

            init {
                view.setOnClickListener {
                    if (day.date.isBefore(startDate)) {
                        return@setOnClickListener
                    }
                    if (day.date.isAfter(endDate)) {
                        return@setOnClickListener
                    }
                    selectDate(day.date)
                }
            }
        }
        binding.calendarView.dayBinder = object : DayBinder<DayViewContainer> {
            override fun create(view: View) = DayViewContainer(view)
            override fun bind(container: DayViewContainer, day: CalendarDay) {
                container.day = day
                val textView = container.binding.exThreeDayText
                val dotView = container.binding.exThreeDotView
                dotView.makeInVisible()
                textView.text = day.date.dayOfMonth.toString()


                if (day.owner == DayOwner.THIS_MONTH) {
                    textView.makeVisible()
                    when {
                        day.date == selectedDate -> {
                            textView.setTextColorRes(R.color.white)
                            textView.setBackgroundResource(R.drawable.example_3_selected_bg)
                        }
                        day.date == today -> {
                            textView.setTextColorRes(R.color.example_3_blue)
                            textView.setBackgroundResource(R.drawable.example_3_today_bg)
                        }
                        startDate != null && endDate != null && (day.date >= startDate && day.date <= endDate) -> {
                            textView.setTextColorRes(R.color.example_3_black)
                            textView.background = null
                        }
                        else -> {
                            textView.setTextColorRes(R.color.example_4_grey_past)
                            textView.background = null
                        }
                    }
                } else {
                    textView.makeInVisible()
                }
            }
        }

        binding.calendarView.monthScrollListener = {
            titleFormatter.format(it.yearMonth)
            binding.exFiveMonthYearText.text = titleFormatter.format(it.yearMonth)
            if (it.month <= startDate!!.month.value) {
                binding.btnPreviousMonth.visibility = View.INVISIBLE
            } else if (it.month >= endDate!!.month.value) {
                binding.btnNextMonth.visibility = View.INVISIBLE
            } else {
                binding.btnNextMonth.visibility = View.VISIBLE
                binding.btnPreviousMonth.visibility = View.VISIBLE
            }
        }

        class MonthViewContainer(view: View) : ViewContainer(view) {
            val legendLayout = Example3CalendarHeaderBinding.bind(view).legendLayout.root
        }
        binding.calendarView.monthHeaderBinder = object :
            MonthHeaderFooterBinder<MonthViewContainer> {
            override fun create(view: View) = MonthViewContainer(view)
            override fun bind(container: MonthViewContainer, month: CalendarMonth) {
                // Setup each header day text if we have not done that already.
                if (container.legendLayout.tag == null) {
                    container.legendLayout.tag = month.yearMonth
                    container.legendLayout.children.map { it as TextView }.forEachIndexed { index, tv ->
                        tv.text = daysOfWeek[index].name.first().toString()
                        tv.setTextColorRes(R.color.example_3_black)
                    }
                }
            }
        }
    }
}