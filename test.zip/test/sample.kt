package com.example.viewbinding.sample.modules.main.view

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.children
import androidx.work.*
import com.example.viewbinding.sample.R
import com.example.viewbinding.sample.databinding.ActivityMainBinding
import com.example.viewbinding.sample.databinding.Example3CalendarDayBinding
import com.example.viewbinding.sample.databinding.Example3CalendarHeaderBinding
import com.example.viewbinding.sample.modules.fragment.SampleAdapter
import com.example.viewbinding.sample.modules.main.MyWorker
import com.example.viewbinding.sample.modules.test.BottomSheetDialog
import com.example.viewbinding.sample.modules.wheel.BaseWheelPickerView
import com.example.viewbinding.sample.modules.wheel.TextWheelAdapter
import com.example.viewbinding.sample.modules.wheel.TextWheelPickerView
import com.kizitonwose.calendarview.model.CalendarDay
import com.kizitonwose.calendarview.model.CalendarMonth
import com.kizitonwose.calendarview.model.DayOwner
import com.kizitonwose.calendarview.ui.DayBinder
import com.kizitonwose.calendarview.ui.MonthHeaderFooterBinder
import com.kizitonwose.calendarview.ui.ViewContainer
import com.kizitonwose.calendarview.utils.next
import com.kizitonwose.calendarview.utils.previous
import java.security.SecureRandom
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit


class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityMainBinding

    private lateinit var pickerView: TextWheelPickerView

    private var startDate: LocalDate? = null
    private var endDate: LocalDate? = null

    private var selectedDate: LocalDate? = null
    private val today = LocalDate.now()
    private val titleFormatter = DateTimeFormatter.ofPattern("MMMM yyyy")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =
            com.example.viewbinding.sample.databinding.ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        handleCalendar(savedInstanceState)
    }


    private fun selectDate(date: LocalDate) {
        if (selectedDate != date) {
            val oldDate = selectedDate
            selectedDate = date
            oldDate?.let { binding.exThreeCalendar.notifyDateChanged(it) }
            binding.exThreeCalendar.notifyDateChanged(date)
        }
    }

    private fun handleCalendar(savedInstanceState: Bundle?) {

	startDate = LocalDate.of(2023, 4, 1)
        endDate = LocalDate.of(2023, 7, 1)

        val daysOfWeek = daysOfWeekFromLocale()
        val currentMonth = YearMonth.now()
        binding.exThreeCalendar.apply {
            setup(currentMonth.minusMonths(10), currentMonth.plusMonths(10), daysOfWeek.first())
            scrollToMonth(currentMonth)
        }

        if (savedInstanceState == null) {
            binding.exThreeCalendar.post {
                selectDate(today)
            }
        }

        startDate = LocalDate.of(2023, 4, 1)
        endDate = LocalDate.of(2023, 7, 1)

        binding.exFiveNextMonthImage.setOnClickListener {
            binding.exThreeCalendar.findFirstVisibleMonth()?.let {
                binding.exThreeCalendar.smoothScrollToMonth(it.yearMonth.next)
            }
        }

        binding.exFivePreviousMonthImage.setOnClickListener {
            binding.exThreeCalendar.findFirstVisibleMonth()?.let {
                binding.exThreeCalendar.smoothScrollToMonth(it.yearMonth.previous)
            }
        }

        class DayViewContainer(view: View) : ViewContainer(view) {
            lateinit var day: CalendarDay // Will be set when this container is bound.
            val binding = Example3CalendarDayBinding.bind(view)

            init {
                view.setOnClickListener {
                    if (day.date.isBefore(startDate)) {
                        return@setOnClickListener
                    }
                    if (day.date.isAfter(endDate)) {
                        return@setOnClickListener
                    }
                    selectDate(day.date)
                }
            }
        }
        binding.exThreeCalendar.dayBinder = object : DayBinder<DayViewContainer> {
            override fun create(view: View) = DayViewContainer(view)
            override fun bind(container: DayViewContainer, day: CalendarDay) {
                container.day = day
                val textView = container.binding.exThreeDayText
                val dotView = container.binding.exThreeDotView
                dotView.makeInVisible()
                textView.text = day.date.dayOfMonth.toString()


                if (day.owner == DayOwner.THIS_MONTH) {
                    textView.makeVisible()
                    when {
                        day.date == selectedDate -> {
                            textView.setTextColorRes(R.color.white)
                            textView.setBackgroundResource(R.drawable.example_3_selected_bg)
                        }
                        day.date == today -> {
                            textView.setTextColorRes(R.color.example_3_blue)
                            textView.setBackgroundResource(R.drawable.example_3_today_bg)
                        }
                        startDate != null && endDate != null && (day.date >= startDate && day.date <= endDate) -> {
                            textView.setTextColorRes(R.color.example_3_black)
                            textView.background = null
                        }
                        else -> {
                            textView.setTextColorRes(R.color.example_4_grey_past)
                            textView.background = null
                        }
                    }
                } else {
                    textView.makeInVisible()
                }
            }
        }

        binding.exThreeCalendar.monthScrollListener = {
            titleFormatter.format(it.yearMonth)
            binding.exFiveMonthYearText.text = titleFormatter.format(it.yearMonth)
        }

        class MonthViewContainer(view: View) : ViewContainer(view) {
            val legendLayout = Example3CalendarHeaderBinding.bind(view).legendLayout.root
        }
        binding.exThreeCalendar.monthHeaderBinder = object :
            MonthHeaderFooterBinder<MonthViewContainer> {
            override fun create(view: View) = MonthViewContainer(view)
            override fun bind(container: MonthViewContainer, month: CalendarMonth) {
                // Setup each header day text if we have not done that already.
                if (container.legendLayout.tag == null) {
                    container.legendLayout.tag = month.yearMonth
                    container.legendLayout.children.map { it as TextView }.forEachIndexed { index, tv ->
                        tv.text = daysOfWeek[index].name.first().toString()
                        tv.setTextColorRes(R.color.example_3_black)
                    }
                }
            }
        }
    }
}